使用Xbee 讲一台电脑上显示的ROS_INFO、WARN、ERROR等消息传输到另外一台电脑显示。
注意不要在同一台电脑上测试同时跑send和receive，会造成无限循环！！！
